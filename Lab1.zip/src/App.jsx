import "./App.css";
import Todolist from "./Todolist/list";

function App() {
  return <Todolist />;
}

export default App;
